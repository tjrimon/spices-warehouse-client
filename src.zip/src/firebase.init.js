// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCwyIST0jEr4c-KWg5ibqh1WxQnVGcKjvI",
    authDomain: "spices-warehouse.firebaseapp.com",
    projectId: "spices-warehouse",
    storageBucket: "spices-warehouse.appspot.com",
    messagingSenderId: "961018640500",
    appId: "1:961018640500:web:04334f995e30ad335e7921"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app)
export default auth;